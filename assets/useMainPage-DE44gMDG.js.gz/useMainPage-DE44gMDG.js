import{N as r}from"./index-C3vUr-tr.js";function n(){const e=r();function o(){e.push({name:"reload"})}return{reload:o}}export{n as u};
